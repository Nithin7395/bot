"use strict";

var express = require('express'),
    app = express(),
    bodyParser = require('body-parser'),
    apiai = require('apiai'),
    port = 8080;

var aiapp = apiai("53846aef56774de6ab9a581a44c1357e");

var options = {
    sessionId: 'abcseeedsfaefawefas'
};

app.use(bodyParser());

app.use(express.static(__dirname + '/public'));
app.listen(port, '0.0.0.0', function () {
        console.log("server starting on port " + port);
});



app.post('/api/bot', function(req,res){
var request = aiapp.textRequest(req.body.input.text, options);
request.on('response', function(response) {
    //console.log(response);
    return res.json(response);
});

request.on('error', function(error) {
    console.log(error);
    return res.status(error.code || 500).json(error);
});

request.end();
//response.result.fulfillment.speech
     
})